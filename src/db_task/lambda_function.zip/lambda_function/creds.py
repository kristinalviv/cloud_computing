
# rds settings
rds_host  = "test.cebb9xrwq37s.us-east-1.rds.amazonaws.com"
user_name = "test_mysql"
password = "mysql_999_111_test"
db_name = "test_db"
